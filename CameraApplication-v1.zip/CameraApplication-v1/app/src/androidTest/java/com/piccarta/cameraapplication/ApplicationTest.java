package com.piccarta.cameraapplication;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * Fuck unit tests
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }
}