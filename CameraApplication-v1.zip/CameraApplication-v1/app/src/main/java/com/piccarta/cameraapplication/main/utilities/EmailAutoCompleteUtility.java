package com.piccarta.cameraapplication.main.utilities;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;

/**
 * By: Julian Saavedra
 * GitHub: jfsaaved
 *
 */

public class EmailAutoCompleteUtility {

    private Context mAppContext;
    private SharedPreferences mEmails;

    public EmailAutoCompleteUtility(Context mAppContext){
        this.mAppContext = mAppContext;
        mEmails = mAppContext.getSharedPreferences("EmailAutoComplete", Context.MODE_PRIVATE);
    }

    public Context getContext() {
        return mAppContext;
    }

    public void savePreferences (String value) {
        mEmails = mAppContext.getSharedPreferences("EmailAutoComplete", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mEmails.edit();
        editor.putString("Emails", value);
        editor.apply();
    }

    public void deletePreferences() {

        mEmails = mAppContext.getSharedPreferences("EmailAutoComplete", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mEmails.edit();
        editor.remove("Emails");
        editor.apply();
    }

    public void clearAllPreferences() {
        mEmails = mAppContext.getSharedPreferences("EmailAutoComplete", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mEmails.edit();
        editor.clear();
        editor.apply();
    }

    public String showPreferences(){
        mEmails = mAppContext.getSharedPreferences("EmailAutoComplete", Context.MODE_PRIVATE);
        return mEmails.getString("Emails", "");
    }

    public ArrayList<String> getArray(){
        mEmails = mAppContext.getSharedPreferences("EmailAutoComplete", Context.MODE_PRIVATE);
        ArrayList<String> mPastEmails = new ArrayList<>();

        if(mEmails.getString("Emails","") != null)
            mPastEmails.add(mEmails.getString("Emails", ""));
        else
            mPastEmails.add("");

        return mPastEmails;
    }

}