package com.piccarta.cameraapplication.main.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * By: Julian Saavedra
 * GitHub: jfsaaved
 *
 */
public class AppUtility {

    private Context mAppContext;

    public void setContext(Context mAppContext)
    {
        this.mAppContext = mAppContext;
    }

    public Context getContext(){
        return mAppContext;
    }

    public void savePreferences (String key, String value ,Context contextis) {
        SharedPreferences sharedPreferences =contextis.getSharedPreferences("MyPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public void deletePreferences(String key ,Context contextis) {

        SharedPreferences sharedPreferences = contextis.getSharedPreferences("MyPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(key);
        editor.commit();
    }

    public void clearAllPreferences(Context contextis) {
        SharedPreferences sharedPreferences = contextis.getSharedPreferences("MyPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }
    public String showPreferences(String key ,Context contextis){
        SharedPreferences sharedPreferences = contextis.getSharedPreferences("MyPreferences", Context.MODE_PRIVATE);
        String savedPref = sharedPreferences.getString(key, "");
        return savedPref;
    }
    public boolean hasConnection() {
        ConnectivityManager cm = (ConnectivityManager) mAppContext.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo wifiNetwork = cm.getActiveNetworkInfo();
        if (wifiNetwork != null && wifiNetwork.isConnected()) {
            return true;
        }

        NetworkInfo mobileNetwork = cm.getActiveNetworkInfo();
        if (mobileNetwork != null && mobileNetwork.isConnected()) {
            return true;
        }

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null && activeNetwork.isConnected()) {
            return true;
        }

        return false;
    }

}

