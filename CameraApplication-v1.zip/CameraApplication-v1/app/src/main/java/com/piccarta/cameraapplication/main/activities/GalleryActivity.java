package com.piccarta.cameraapplication.main.activities;

import android.os.Bundle;

import com.piccarta.cameraapplication.R;


/**
 * By: Julian Saavedra
 * GitHub: jfsaaved
 *
 */

public class GalleryActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.activity_gallery, frameLayout);
        mDrawerList.setItemChecked(position, true);
        setTitle(listArray[position]);
    }
}
